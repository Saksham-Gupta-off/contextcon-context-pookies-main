import React, { useMemo } from "react";
import { ArrowLeft, ArrowRight, Wallet, Target, Coins } from "lucide-react";
import { StepHeader } from "../components/StepHeader";

const fmtUSD = (n) => {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
};

export const Capital = ({ state, onChange, onNext, onBack, onExit }) => {
  const { fundSize, numBets, chequeSize, chequeOverridden } = state;

  const derivedCheque = useMemo(() => {
    if (numBets <= 0) return 0;
    return Math.round(fundSize / numBets);
  }, [fundSize, numBets]);

  // Keep cheque linked unless user explicitly overrides it.
  const effectiveCheque = chequeOverridden ? chequeSize : derivedCheque;
  const totalDeployed = effectiveCheque * numBets;
  const deploymentRatio = fundSize > 0 ? Math.min(100, (totalDeployed / fundSize) * 100) : 0;

  const setFundSize = (v) =>
    onChange({ ...state, fundSize: v, chequeSize: chequeOverridden ? state.chequeSize : Math.round(v / numBets) });
  const setNumBets = (v) =>
    onChange({ ...state, numBets: v, chequeSize: chequeOverridden ? state.chequeSize : Math.round(fundSize / v) });
  const setCheque = (v) => onChange({ ...state, chequeSize: v, chequeOverridden: true });
  const resetCheque = () =>
    onChange({ ...state, chequeSize: derivedCheque, chequeOverridden: false });

  return (
    <div className="min-h-screen bg-parchment" data-testid="capital-page">
      <StepHeader current="capital" onExit={onExit} />

      <main className="max-w-5xl mx-auto px-5 md:px-8 py-10 md:py-14">
        <div className="mb-10 slide-up">
          <div className="font-mono text-[0.7rem] uppercase tracking-[0.22em] text-tomato mb-3">
            Step 02 / 04 — Configure capital
          </div>
          <h1 className="font-display text-3xl md:text-5xl text-ink leading-[1.04] max-w-3xl">
            How much powder, how many bets, what size cheque?
          </h1>
          <p className="mt-4 text-base md:text-lg text-ink/70 max-w-2xl">
            Eugene K. uses this to size the portfolio against the power law.
            More bets = more lottery tickets.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-5 mb-8">
          {/* FUND SIZE */}
          <div className="kk-panel p-6 slide-up" data-testid="fund-size-card">
            <div className="flex items-center gap-3 mb-4">
              <div
                className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
                style={{ background: "var(--avocado)", boxShadow: "3px 3px 0 0 var(--ink)" }}
              >
                <Wallet size={20} strokeWidth={3} className="text-white" />
              </div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Total fund
              </div>
            </div>
            <div className="font-display text-4xl text-ink mb-4">{fmtUSD(fundSize)}</div>
            <input
              type="range"
              min={1_000_000}
              max={100_000_000}
              step={500_000}
              value={fundSize}
              onChange={(e) => setFundSize(Number(e.target.value))}
              className="kk-slider"
              data-testid="fund-size-slider"
            />
            <div className="flex justify-between font-mono text-[0.65rem] uppercase tracking-widest text-ink/50 mt-2">
              <span>$1M</span>
              <span>$100M</span>
            </div>
          </div>

          {/* NUM BETS */}
          <div
            className="kk-panel p-6 slide-up"
            style={{ animationDelay: "80ms" }}
            data-testid="num-bets-card"
          >
            <div className="flex items-center gap-3 mb-4">
              <div
                className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
                style={{ background: "var(--tomato)", boxShadow: "3px 3px 0 0 var(--ink)" }}
              >
                <Target size={20} strokeWidth={3} className="text-white" />
              </div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Number of bets
              </div>
            </div>
            <div className="font-display text-4xl text-ink mb-4">{numBets}</div>
            <input
              type="range"
              min={5}
              max={200}
              step={1}
              value={numBets}
              onChange={(e) => setNumBets(Number(e.target.value))}
              className="kk-slider"
              data-testid="num-bets-slider"
            />
            <div className="flex justify-between font-mono text-[0.65rem] uppercase tracking-widest text-ink/50 mt-2">
              <span>5</span>
              <span>200</span>
            </div>
          </div>

          {/* CHEQUE SIZE */}
          <div
            className="kk-panel p-6 slide-up"
            style={{ animationDelay: "160ms" }}
            data-testid="cheque-card"
          >
            <div className="flex items-center gap-3 mb-4">
              <div
                className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
                style={{ background: "var(--yellow)", boxShadow: "3px 3px 0 0 var(--ink)" }}
              >
                <Coins size={20} strokeWidth={3} className="text-ink" />
              </div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Standard cheque
              </div>
            </div>
            <div className="font-display text-4xl text-ink mb-2">{fmtUSD(effectiveCheque)}</div>
            <div className="font-mono text-[0.7rem] text-ink/55 mb-4">
              {chequeOverridden ? "Override active" : `Auto-sized ( fund ÷ bets )`}
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={effectiveCheque}
                onChange={(e) => setCheque(Number(e.target.value))}
                className="kk-input"
                min={10_000}
                step={10_000}
                data-testid="cheque-input"
              />
              {chequeOverridden && (
                <button
                  onClick={resetCheque}
                  className="kk-chip kk-chip-yellow"
                  data-testid="cheque-reset-btn"
                >
                  Reset
                </button>
              )}
            </div>
          </div>
        </div>

        {/* DEPLOYMENT SUMMARY */}
        <div
          className="kk-panel p-6 mb-8 slide-up"
          style={{ animationDelay: "220ms" }}
          data-testid="deployment-summary"
        >
          <div className="flex flex-wrap items-end justify-between gap-4 mb-4">
            <div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Deployment forecast
              </div>
              <div className="font-display text-2xl text-ink mt-1">
                {fmtUSD(totalDeployed)} / {fmtUSD(fundSize)}
              </div>
            </div>
            <div
              className={`kk-chip ${
                deploymentRatio > 100
                  ? "kk-chip-tomato"
                  : deploymentRatio > 95
                  ? "kk-chip-yellow"
                  : "kk-chip-avocado"
              }`}
            >
              {deploymentRatio > 100
                ? `${deploymentRatio.toFixed(0)}% — exceeds fund size`
                : `${deploymentRatio.toFixed(0)}% deployed`}
            </div>
          </div>
          {/* Bar */}
          <div
            className="w-full h-5 rounded-full border-[2.5px] border-ink bg-white overflow-hidden"
            style={{ boxShadow: "3px 3px 0 0 var(--ink)" }}
          >
            <div
              className="h-full transition-all"
              style={{
                width: `${Math.min(100, deploymentRatio)}%`,
                background: deploymentRatio > 100 ? "var(--tomato)" : "var(--avocado)",
              }}
            />
          </div>
          <div className="mt-4 grid sm:grid-cols-3 gap-3">
            <Stat label="Per cheque" value={fmtUSD(effectiveCheque)} />
            <Stat label="Total bets" value={numBets} />
            <Stat
              label="Reserve"
              value={
                fundSize - totalDeployed >= 0
                  ? fmtUSD(fundSize - totalDeployed)
                  : `−${fmtUSD(totalDeployed - fundSize)}`
              }
            />
          </div>
        </div>

        {/* NAV */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-3">
          <button
            onClick={onBack}
            className="kk-btn kk-btn-ghost"
            data-testid="capital-back-btn"
          >
            <ArrowLeft size={16} strokeWidth={3} />
            Back
          </button>
          <button
            onClick={onNext}
            disabled={fundSize <= 0 || numBets <= 0 || effectiveCheque <= 0}
            className="kk-btn"
            data-testid="capital-next-btn"
          >
            Set block filters
            <ArrowRight size={18} strokeWidth={3} />
          </button>
        </div>
      </main>
    </div>
  );
};

const Stat = ({ label, value }) => (
  <div
    className="rounded-xl border-[2.5px] border-ink bg-parchment px-4 py-3"
    style={{ boxShadow: "3px 3px 0 0 var(--ink)" }}
  >
    <div className="font-mono text-[0.65rem] uppercase tracking-widest text-ink/55">{label}</div>
    <div className="font-display text-lg text-ink mt-0.5">{value}</div>
  </div>
);

export default Capital;
