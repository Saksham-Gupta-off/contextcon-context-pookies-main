import React, { useState } from "react";
import { ArrowLeft, ArrowRight, Globe, Ban, Plus, X } from "lucide-react";
import { StepHeader } from "../components/StepHeader";

const DEFAULT_GEOS = ["Russia", "Iran", "China"];
const DEFAULT_SECTORS = ["Gambling", "Crypto", "Defense", "Tobacco"];

const ALL_GEO_SUGGESTIONS = ["North Korea", "Belarus", "Myanmar", "Venezuela", "Syria"];
const ALL_SECTOR_SUGGESTIONS = [
  "Adult content",
  "Vapes",
  "Firearms",
  "Fossil fuels",
  "Payday lending",
  "Surveillance",
];

export const Blocks = ({ state, onChange, onNext, onBack, onExit }) => {
  const { blockedGeos, blockedSectors, customBlocks } = state;
  const [customInput, setCustomInput] = useState("");
  const [customKind, setCustomKind] = useState("sector");

  const toggleGeo = (g) =>
    onChange({
      ...state,
      blockedGeos: blockedGeos.includes(g)
        ? blockedGeos.filter((x) => x !== g)
        : [...blockedGeos, g],
    });
  const toggleSector = (s) =>
    onChange({
      ...state,
      blockedSectors: blockedSectors.includes(s)
        ? blockedSectors.filter((x) => x !== s)
        : [...blockedSectors, s],
    });

  const addCustom = () => {
    const val = customInput.trim();
    if (!val) return;
    if (customBlocks.some((c) => c.value.toLowerCase() === val.toLowerCase())) return;
    onChange({
      ...state,
      customBlocks: [...customBlocks, { value: val, kind: customKind }],
    });
    setCustomInput("");
  };
  const removeCustom = (val) =>
    onChange({
      ...state,
      customBlocks: customBlocks.filter((c) => c.value !== val),
    });

  const geoSuggestions = ALL_GEO_SUGGESTIONS.filter((g) => !blockedGeos.includes(g));
  const sectorSuggestions = ALL_SECTOR_SUGGESTIONS.filter((s) => !blockedSectors.includes(s));

  return (
    <div className="min-h-screen bg-parchment" data-testid="blocks-page">
      <StepHeader current="blocks" onExit={onExit} />

      <main className="max-w-5xl mx-auto px-5 md:px-8 py-10 md:py-14">
        <div className="mb-10 slide-up">
          <div className="font-mono text-[0.7rem] uppercase tracking-[0.22em] text-tomato mb-3">
            Step 03 / 04 — Block filters
          </div>
          <h1 className="font-display text-3xl md:text-5xl text-ink leading-[1.04] max-w-3xl">
            What shouldn't Mr. Krabs touch with a ten-foot pincer?
          </h1>
          <p className="mt-4 text-base md:text-lg text-ink/70 max-w-2xl">
            Any company matching these blocks is removed from sourcing, no matter how hot the thesis.
          </p>
        </div>

        {/* GEOGRAPHIES */}
        <div className="kk-panel p-6 mb-6 slide-up" data-testid="geos-panel">
          <div className="flex items-center gap-3 mb-4">
            <div
              className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
              style={{ background: "var(--aqua)", boxShadow: "3px 3px 0 0 var(--ink)" }}
            >
              <Globe size={20} strokeWidth={3} className="text-white" />
            </div>
            <div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Blocked geographies
              </div>
              <div className="font-display text-xl text-ink">Where we won't deploy</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {[...DEFAULT_GEOS, ...blockedGeos.filter((g) => !DEFAULT_GEOS.includes(g))].map((g) => {
              const isBlocked = blockedGeos.includes(g);
              return (
                <button
                  key={g}
                  onClick={() => toggleGeo(g)}
                  className={`kk-chip ${isBlocked ? "kk-chip-tomato" : ""}`}
                  data-testid={`geo-chip-${g.toLowerCase().replace(/\s/g, "-")}`}
                >
                  {isBlocked ? <Ban size={12} strokeWidth={3} /> : <Plus size={12} strokeWidth={3} />}
                  {g}
                </button>
              );
            })}
          </div>
          {geoSuggestions.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[0.65rem] uppercase tracking-widest text-ink/50 mr-1">
                Add:
              </span>
              {geoSuggestions.map((g) => (
                <button
                  key={g}
                  onClick={() => toggleGeo(g)}
                  className="kk-chip"
                  data-testid={`geo-suggest-${g.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <Plus size={12} strokeWidth={3} />
                  {g}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* SECTORS */}
        <div
          className="kk-panel p-6 mb-6 slide-up"
          style={{ animationDelay: "80ms" }}
          data-testid="sectors-panel"
        >
          <div className="flex items-center gap-3 mb-4">
            <div
              className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
              style={{ background: "var(--tomato)", boxShadow: "3px 3px 0 0 var(--ink)" }}
            >
              <Ban size={20} strokeWidth={3} className="text-white" />
            </div>
            <div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Blocked sectors
              </div>
              <div className="font-display text-xl text-ink">Categories we skip</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {[
              ...DEFAULT_SECTORS,
              ...blockedSectors.filter((s) => !DEFAULT_SECTORS.includes(s)),
            ].map((s) => {
              const isBlocked = blockedSectors.includes(s);
              return (
                <button
                  key={s}
                  onClick={() => toggleSector(s)}
                  className={`kk-chip ${isBlocked ? "kk-chip-tomato" : ""}`}
                  data-testid={`sector-chip-${s.toLowerCase().replace(/\s/g, "-")}`}
                >
                  {isBlocked ? <Ban size={12} strokeWidth={3} /> : <Plus size={12} strokeWidth={3} />}
                  {s}
                </button>
              );
            })}
          </div>
          {sectorSuggestions.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[0.65rem] uppercase tracking-widest text-ink/50 mr-1">
                Add:
              </span>
              {sectorSuggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => toggleSector(s)}
                  className="kk-chip"
                  data-testid={`sector-suggest-${s.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <Plus size={12} strokeWidth={3} />
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* CUSTOM */}
        <div
          className="kk-panel p-6 mb-8 slide-up"
          style={{ animationDelay: "160ms" }}
          data-testid="custom-panel"
        >
          <div className="flex items-center gap-3 mb-4">
            <div
              className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
              style={{ background: "var(--yellow)", boxShadow: "3px 3px 0 0 var(--ink)" }}
            >
              <Plus size={20} strokeWidth={3} className="text-ink" />
            </div>
            <div>
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                Your custom blocks
              </div>
              <div className="font-display text-xl text-ink">Anything else off-limits?</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <select
              value={customKind}
              onChange={(e) => setCustomKind(e.target.value)}
              className="kk-input sm:max-w-[160px]"
              data-testid="custom-kind-select"
            >
              <option value="sector">Sector</option>
              <option value="geo">Geography</option>
              <option value="stage">Stage</option>
              <option value="tag">Keyword</option>
            </select>
            <input
              type="text"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addCustom()}
              placeholder="e.g. Pre-seed bootstrapped, Latam only, etc."
              className="kk-input flex-1"
              data-testid="custom-input"
            />
            <button
              onClick={addCustom}
              className="kk-btn kk-btn-avocado"
              data-testid="custom-add-btn"
            >
              <Plus size={16} strokeWidth={3} />
              Add block
            </button>
          </div>

          {customBlocks.length === 0 ? (
            <p className="font-mono text-[0.72rem] text-ink/50 italic">
              No custom blocks yet. Mr. Krabs is holding his pincers loose.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {customBlocks.map((c) => (
                <span
                  key={c.value}
                  className="kk-chip kk-chip-tomato"
                  data-testid={`custom-chip-${c.value.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <span className="font-mono text-[0.6rem] uppercase opacity-80">
                    {c.kind}
                  </span>
                  {c.value}
                  <button
                    onClick={() => removeCustom(c.value)}
                    className="ml-1 hover:scale-110 transition-transform"
                    aria-label={`Remove ${c.value}`}
                  >
                    <X size={12} strokeWidth={3} />
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* NAV */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-3">
          <button
            onClick={onBack}
            className="kk-btn kk-btn-ghost"
            data-testid="blocks-back-btn"
          >
            <ArrowLeft size={16} strokeWidth={3} />
            Back
          </button>
          <button onClick={onNext} className="kk-btn" data-testid="blocks-next-btn">
            Review everything
            <ArrowRight size={18} strokeWidth={3} />
          </button>
        </div>
      </main>
    </div>
  );
};

export default Blocks;
