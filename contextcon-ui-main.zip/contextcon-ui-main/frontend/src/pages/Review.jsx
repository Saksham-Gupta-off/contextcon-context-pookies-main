import React, { useState } from "react";
import {
  ArrowLeft,
  Rocket,
  Edit3,
  Building2,
  Wallet,
  Globe,
  Ban,
  CheckCircle2,
} from "lucide-react";
import { StepHeader } from "../components/StepHeader";
import { KrabsMascot } from "../components/KrabsMascot";
import { toast } from "sonner";

const fmtUSD = (n) => {
  if (!n) return "$0";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
};

const FUND_LABEL_MAP = {
  "a16z-6mo": "a16z · Last 6 months",
  "yc-p26": "YC P26",
  "yc-w26": "YC W26",
  "yc-f25": "YC F25",
  "yc-s25": "YC S25",
};

export const Review = ({ state, onEdit, onBack, onExit, onConfirm }) => {
  const [submitted, setSubmitted] = useState(false);
  const { funds, capital, blocks } = state;

  const handleConfirm = () => {
    setSubmitted(true);
    toast.success("Thesis locked in — portfolio construction unlocked", {
      description: "Eugene K. is calling Crustdata and getting the first batch.",
    });
    onConfirm();
  };

  const totalDeployed =
    (capital.chequeOverridden
      ? capital.chequeSize
      : Math.round(capital.fundSize / capital.numBets)) * capital.numBets;

  return (
    <div className="min-h-screen bg-parchment" data-testid="review-page">
      <StepHeader current="review" onExit={onExit} />

      <main className="max-w-6xl mx-auto px-5 md:px-8 py-10 md:py-14">
        <div className="grid lg:grid-cols-[1fr_auto] gap-6 items-start mb-10">
          <div className="slide-up">
            <div className="font-mono text-[0.7rem] uppercase tracking-[0.22em] text-tomato mb-3">
              Step 04 / 04 — Review
            </div>
            <h1 className="font-display text-3xl md:text-5xl text-ink leading-[1.04] max-w-3xl">
              One last look before Eugene K. drops the anchor.
            </h1>
            <p className="mt-4 text-base md:text-lg text-ink/70 max-w-2xl">
              Everything below can be tweaked later — but this is the config that kicks
              off portfolio construction.
            </p>
          </div>
          <div className="hidden md:block">
            <KrabsMascot size={140} />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-5 mb-8">
          {/* FUNDS */}
          <ReviewCard
            testid="review-funds"
            accent="var(--aqua)"
            icon={Building2}
            kicker="Shadowing"
            title={`${funds.length} fund${funds.length === 1 ? "" : "s"}`}
            onEdit={() => onEdit("funds")}
          >
            {funds.length === 0 ? (
              <p className="text-ink/60 italic text-sm">No funds selected yet.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {funds.map((f) => (
                  <span key={f} className="kk-chip kk-chip-aqua">
                    {FUND_LABEL_MAP[f] || f}
                  </span>
                ))}
              </div>
            )}
          </ReviewCard>

          {/* CAPITAL */}
          <ReviewCard
            testid="review-capital"
            accent="var(--avocado)"
            icon={Wallet}
            kicker="Capital"
            title={`${fmtUSD(capital.fundSize)} fund`}
            onEdit={() => onEdit("capital")}
          >
            <div className="grid grid-cols-3 gap-2">
              <MiniStat label="Bets" value={capital.numBets} />
              <MiniStat
                label="Cheque"
                value={fmtUSD(
                  capital.chequeOverridden
                    ? capital.chequeSize
                    : Math.round(capital.fundSize / capital.numBets),
                )}
              />
              <MiniStat label="Deployed" value={fmtUSD(totalDeployed)} />
            </div>
          </ReviewCard>

          {/* GEOS */}
          <ReviewCard
            testid="review-geos"
            accent="var(--tomato)"
            icon={Globe}
            kicker="Blocked geographies"
            title={`${blocks.blockedGeos.length} region${
              blocks.blockedGeos.length === 1 ? "" : "s"
            }`}
            onEdit={() => onEdit("blocks")}
          >
            <div className="flex flex-wrap gap-2">
              {blocks.blockedGeos.map((g) => (
                <span key={g} className="kk-chip kk-chip-tomato">
                  <Ban size={10} strokeWidth={3} />
                  {g}
                </span>
              ))}
            </div>
          </ReviewCard>

          {/* SECTORS + CUSTOM */}
          <ReviewCard
            testid="review-sectors"
            accent="var(--yellow)"
            icon={Ban}
            kicker="Blocked sectors + custom"
            title={`${blocks.blockedSectors.length + blocks.customBlocks.length} filters`}
            onEdit={() => onEdit("blocks")}
          >
            <div className="flex flex-wrap gap-2">
              {blocks.blockedSectors.map((s) => (
                <span key={s} className="kk-chip kk-chip-tomato">
                  <Ban size={10} strokeWidth={3} />
                  {s}
                </span>
              ))}
              {blocks.customBlocks.map((c) => (
                <span key={c.value} className="kk-chip kk-chip-avocado">
                  <span className="font-mono text-[0.58rem] uppercase opacity-80">{c.kind}</span>
                  {c.value}
                </span>
              ))}
            </div>
          </ReviewCard>
        </div>

        {/* CONFIRM STRIP */}
        {!submitted ? (
          <div
            className="kk-panel p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 plank-stripes"
            data-testid="confirm-strip"
          >
            <div className="max-w-xl">
              <div className="font-mono text-[0.7rem] uppercase tracking-[0.22em] text-tomato mb-1">
                Next stop: portfolio construction
              </div>
              <div className="font-display text-xl text-ink">
                Eugene K. will pull matching second movers from Crustdata and score them
                against your thesis signal.
              </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0">
              <button
                onClick={onBack}
                className="kk-btn kk-btn-ghost"
                data-testid="review-back-btn"
              >
                <ArrowLeft size={16} strokeWidth={3} />
                Back
              </button>
              <button
                onClick={handleConfirm}
                disabled={funds.length === 0}
                className="kk-btn"
                data-testid="review-confirm-btn"
              >
                Build my portfolio
                <Rocket size={18} strokeWidth={3} />
              </button>
            </div>
          </div>
        ) : (
          <div
            className="kk-panel p-8 text-center slide-up"
            style={{ background: "var(--avocado)" }}
            data-testid="success-strip"
          >
            <div className="inline-grid place-items-center w-16 h-16 rounded-full border-[2.5px] border-ink bg-white mx-auto mb-4">
              <CheckCircle2 size={30} strokeWidth={3} className="text-avocado" />
            </div>
            <h2 className="font-display text-3xl text-white leading-tight">
              Thesis locked. Eugene K. is sourcing.
            </h2>
            <p className="mt-3 text-white/90 max-w-xl mx-auto">
              Portfolio construction will be ready in your next session — we'll surface
              ranked second movers across your shadowed theses.
            </p>
            <div className="mt-6 inline-flex flex-wrap gap-2 justify-center">
              <span className="kk-chip kk-chip-yellow">Queued: {funds.length} theses</span>
              <span className="kk-chip kk-chip-aqua">
                Budget: {fmtUSD(capital.fundSize)} · {capital.numBets} bets
              </span>
              <span className="kk-chip">
                Blocks: {blocks.blockedGeos.length + blocks.blockedSectors.length + blocks.customBlocks.length}
              </span>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

const ReviewCard = ({ icon: Icon, accent, kicker, title, onEdit, children, testid }) => (
  <div className="kk-panel p-5 slide-up" data-testid={testid}>
    <div className="flex items-start justify-between gap-3 mb-4">
      <div className="flex items-center gap-3">
        <div
          className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink"
          style={{ background: accent, boxShadow: "3px 3px 0 0 var(--ink)" }}
        >
          <Icon size={20} strokeWidth={3} className="text-white" />
        </div>
        <div>
          <div className="font-mono text-[0.65rem] uppercase tracking-[0.22em] text-ink/55">
            {kicker}
          </div>
          <div className="font-display text-lg text-ink">{title}</div>
        </div>
      </div>
      <button
        onClick={onEdit}
        className="kk-chip"
        data-testid={`${testid}-edit`}
        aria-label="Edit"
      >
        <Edit3 size={11} strokeWidth={3} />
        Edit
      </button>
    </div>
    <div>{children}</div>
  </div>
);

const MiniStat = ({ label, value }) => (
  <div
    className="rounded-lg border-[2.5px] border-ink bg-parchment px-3 py-2"
    style={{ boxShadow: "2px 2px 0 0 var(--ink)" }}
  >
    <div className="font-mono text-[0.6rem] uppercase tracking-widest text-ink/55">{label}</div>
    <div className="font-display text-base text-ink">{value}</div>
  </div>
);

export default Review;
