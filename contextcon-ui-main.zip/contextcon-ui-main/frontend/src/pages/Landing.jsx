import React from "react";
import { ArrowRight, Database, Sparkles, TrendingUp, Shield, Zap } from "lucide-react";
import { KrabsMascot } from "../components/KrabsMascot";
import { CrustyLogo } from "../components/CrustyLogo";
import { OceanBubbles } from "../components/OceanBubbles";

export const Landing = ({ onStart }) => {
  return (
    <div className="min-h-screen sand-bg" data-testid="landing-page">
      {/* NAVBAR */}
      <nav className="w-full border-b-[2.5px] border-ink bg-parchment">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-4 flex items-center justify-between">
          <CrustyLogo />
          <div className="hidden md:flex items-center gap-6 font-mono text-[0.72rem] uppercase tracking-[0.2em] text-ink/70">
            <a href="#thesis" className="hover:text-tomato transition-colors">Thesis</a>
            <a href="#how" className="hover:text-tomato transition-colors">How it works</a>
            <a href="#signals" className="hover:text-tomato transition-colors">Signals</a>
          </div>
          <button
            onClick={onStart}
            className="kk-btn kk-btn-yellow"
            data-testid="nav-start-btn"
          >
            Launch onboarding
            <ArrowRight size={16} strokeWidth={3} />
          </button>
        </div>
        <div className="pattern-bar" />
      </nav>

      {/* ============ HERO ============ */}
      <section className="relative max-w-6xl mx-auto px-5 md:px-8 pt-12 md:pt-20 pb-20">
        <div className="grid lg:grid-cols-[1.3fr_1fr] gap-10 items-center">
          <div className="slide-up">
            <div className="inline-flex kk-chip kk-chip-avocado mb-6" data-testid="hero-pill">
              <Sparkles size={14} strokeWidth={3} />
              AI-native venture fund · Fund I open
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-[4.3rem] leading-[0.98] text-ink">
              The AI GP that spots{" "}
              <span className="relative inline-block">
                <span className="relative z-10 text-tomato">second movers</span>
                <span
                  className="absolute inset-x-0 bottom-1 h-3 z-0 opacity-60"
                  style={{ background: "var(--yellow)" }}
                />
              </span>
              {" "}before they smell like money.
            </h1>

            <p className="mt-6 text-base md:text-lg text-ink/75 max-w-xl leading-relaxed">
              Meet <b className="text-ink">Eugene K.</b> — our AI General Partner. He doesn't
              chase a16z's next deal. He tails their{" "}
              <span className="font-mono text-tomato">thesis</span>, then hunts the second
              mover in the same category — cheaper, earlier, before the herd crowds in.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={onStart}
                className="kk-btn"
                data-testid="hero-cta-primary"
              >
                Start sourcing deals
                <ArrowRight size={18} strokeWidth={3} />
              </button>
              <a href="#thesis" className="kk-btn kk-btn-ghost" data-testid="hero-cta-secondary">
                Read the thesis
              </a>
            </div>

            {/* Signal strip */}
            <div
              className="mt-10 inline-flex items-center gap-3 px-4 py-2.5 bg-white border-[2.5px] border-ink rounded-full"
              style={{ boxShadow: "4px 4px 0 0 var(--ink)" }}
              data-testid="crustdata-hint"
            >
              <Database size={16} strokeWidth={3} className="text-aqua" />
              <span className="font-mono text-[0.72rem] uppercase tracking-[0.18em] text-ink/70">
                Signal feed:
              </span>
              <span className="font-display text-sm text-ink">Crustdata Company API</span>
              <span className="w-1.5 h-1.5 rounded-full bg-avocado animate-pulse" />
            </div>
          </div>

          {/* KRABS HERO PORTRAIT */}
          <div className="relative flex justify-center lg:justify-end">
            <div
              className="relative ocean-bg rounded-[32px] border-[2.5px] border-ink p-6 w-full max-w-md"
              style={{ boxShadow: "10px 10px 0 0 var(--ink)" }}
            >
              <OceanBubbles count={12} />
              <div className="relative z-10 flex flex-col items-center">
                <div
                  className="absolute top-0 left-0 -translate-x-2 -translate-y-6 kk-chip kk-chip-yellow money-float"
                  style={{ transform: "rotate(-8deg)" }}
                >
                  💰 ROI in sight
                </div>
                <KrabsMascot size={260} />
                <div className="krabs-shadow" />
                <div className="mt-3 w-full bg-white border-[2.5px] border-ink rounded-2xl p-4 speech-bubble relative">
                  <div className="font-mono text-[0.65rem] uppercase tracking-widest text-tomato mb-1">
                    Eugene K. · AI GP
                  </div>
                  <div className="font-display text-[0.95rem] leading-snug">
                    "Arrr — I don't invest in the first mover. I invest in the cheaper one right behind 'em."
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trust band */}
        <div className="mt-14 flex flex-wrap items-center gap-3">
          <span className="font-mono text-[0.7rem] uppercase tracking-[0.2em] text-ink/60">
            Shadowing thesis from:
          </span>
          <div className="kk-chip">a16z · last 6mo</div>
          <div className="kk-chip">YC P26</div>
          <div className="kk-chip">YC W26</div>
          <div className="kk-chip">YC F25</div>
          <div className="kk-chip">YC S25</div>
        </div>
      </section>

      {/* ============ THESIS ============ */}
      <section
        id="thesis"
        className="relative ocean-bg py-20 border-y-[2.5px] border-ink"
      >
        <OceanBubbles count={22} />
        <div className="max-w-6xl mx-auto px-5 md:px-8 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-flex kk-chip kk-chip-yellow mb-5">
              <TrendingUp size={14} strokeWidth={3} />
              The thesis
            </div>
            <h2 className="font-display text-3xl md:text-5xl text-white leading-[1.02]">
              Venture returns follow a <span className="text-yellow-pepper">power law</span>.
              So we maximize the portfolio — minimize the bias.
            </h2>
            <p className="mt-6 text-white/85 text-base md:text-lg max-w-2xl leading-relaxed">
              A handful of outliers return entire funds. Real sourcing at scale is a
              full-time job that drowns most GPs. Crusty Crab flips the problem: the
              winning theses are already public — we just need the <i>second</i> name
              on the list, at a sane price.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-14">
            {[
              {
                icon: TrendingUp,
                color: "var(--tomato)",
                title: "Follow the money, not the deck",
                body: "We ingest a16z + YC investment patterns and extract the thesis signal — not the headline deal.",
              },
              {
                icon: Zap,
                color: "var(--yellow)",
                title: "Catch second movers early",
                body: "Crustdata finds comparable companies in the same thesis before the category gets crowded and expensive.",
              },
              {
                icon: Shield,
                color: "var(--avocado)",
                title: "Your filters, your sleep",
                body: "Block geographies, sectors, stages. Eugene K. only shows you deals that pass your gate.",
              },
            ].map((c, i) => (
              <div
                key={i}
                className="kk-panel p-6 slide-up"
                style={{ animationDelay: `${i * 120}ms` }}
                data-testid={`thesis-card-${i}`}
              >
                <div
                  className="inline-grid place-items-center w-12 h-12 rounded-xl border-[2.5px] border-ink mb-4"
                  style={{ background: c.color, boxShadow: "3px 3px 0 0 var(--ink)" }}
                >
                  <c.icon size={22} strokeWidth={3} className="text-ink" />
                </div>
                <h3 className="font-display text-xl text-ink leading-snug">{c.title}</h3>
                <p className="mt-2 text-ink/75 text-[0.95rem] leading-relaxed">{c.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ HOW IT WORKS ============ */}
      <section id="how" className="relative py-20">
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
            <div>
              <div className="inline-flex kk-chip kk-chip-tomato mb-4">
                <Zap size={14} strokeWidth={3} />
                Four-step onboarding
              </div>
              <h2 className="font-display text-3xl md:text-5xl text-ink leading-[1.02] max-w-2xl">
                From empty portfolio to sourcing pipeline in under <span className="text-tomato">5 minutes</span>.
              </h2>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-5">
            {[
              { n: "01", label: "Shadow funds", desc: "Pick a16z, YC batches — or bring your own." },
              { n: "02", label: "Configure capital", desc: "Fund size, bets, average cheque — Eugene does the math." },
              { n: "03", label: "Block filters", desc: "Geographies, sectors, anything Mr. Krabs doesn't touch." },
              { n: "04", label: "Build portfolio", desc: "Review, approve, and watch the pipeline fill." },
            ].map((s, i) => (
              <div
                key={s.n}
                className="kk-panel p-5 plank-stripes slide-up relative overflow-hidden"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div
                  className="font-shade text-5xl mb-2"
                  style={{ color: "var(--aqua)" }}
                >
                  {s.n}
                </div>
                <h3 className="font-display text-lg text-ink">{s.label}</h3>
                <p className="mt-1 text-sm text-ink/70 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ Signals / Marquee ============ */}
      <section
        id="signals"
        className="relative border-y-[2.5px] border-ink bg-tomato overflow-hidden py-5"
      >
        <div className="marquee-track">
          {[...Array(2)].map((_, j) => (
            <div key={j} className="flex items-center gap-8 px-8">
              {[
                "POWERED BY CRUSTDATA",
                "★",
                "SECOND-MOVER ARBITRAGE",
                "★",
                "POWER-LAW PORTFOLIOS",
                "★",
                "EUGENE K. · AI GP",
                "★",
                "BIKINI BOTTOM HQ",
                "★",
              ].map((t, i) => (
                <span
                  key={i}
                  className="font-display text-white text-xl md:text-2xl whitespace-nowrap"
                >
                  {t}
                </span>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ============ BOTTOM CTA ============ */}
      <section className="py-24 relative">
        <div className="max-w-4xl mx-auto px-5 md:px-8 text-center">
          <h2 className="font-display text-3xl md:text-5xl text-ink leading-[1.02]">
            Ready to let Eugene K. do the sourcing?
          </h2>
          <p className="mt-5 text-lg text-ink/70 max-w-xl mx-auto">
            Four screens. No pitch decks. Just a portfolio-building machine that
            actually reads the market.
          </p>
          <div className="mt-9">
            <button
              onClick={onStart}
              className="kk-btn"
              data-testid="bottom-cta-btn"
            >
              Open the onboarding
              <ArrowRight size={18} strokeWidth={3} />
            </button>
          </div>
          <div className="mt-10 flex items-center justify-center gap-2 font-mono text-[0.72rem] uppercase tracking-[0.2em] text-ink/50">
            <Database size={13} strokeWidth={3} />
            Signal layer: Crustdata Company API · Thesis layer: a16z + YC · GP layer: Eugene K.
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-[2.5px] border-ink bg-ink text-white py-8">
        <div className="max-w-6xl mx-auto px-5 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="grid place-items-center w-8 h-8 rounded-md bg-tomato border-2 border-white"
            >
              <span className="font-display text-white text-xs">C</span>
            </div>
            <span className="font-display text-sm">CRUSTY CRAB VENTURES</span>
          </div>
          <div className="font-mono text-[0.68rem] uppercase tracking-[0.2em] text-white/60">
            © 2026 · Bikini Bottom HQ · Fund I
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
