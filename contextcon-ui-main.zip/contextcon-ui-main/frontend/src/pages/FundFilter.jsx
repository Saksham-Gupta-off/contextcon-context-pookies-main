import React from "react";
import { ArrowLeft, ArrowRight, Check, Building2, Rocket } from "lucide-react";
import { StepHeader } from "../components/StepHeader";
import { KrabsMascot } from "../components/KrabsMascot";

const FUND_OPTIONS = [
  {
    id: "a16z-6mo",
    org: "a16z",
    label: "Andreessen Horowitz",
    cadence: "Last 6 months",
    thesis: "AI infra · fintech rails · defense tech · creator economy",
    color: "var(--tomato)",
    icon: Building2,
    deals: "~142 deals",
  },
  {
    id: "yc-p26",
    org: "YC",
    label: "Y Combinator P26",
    cadence: "Pilot 2026",
    thesis: "Vertical AI agents · dev tools · healthcare ops",
    color: "var(--yellow)",
    icon: Rocket,
    deals: "~240 startups",
  },
  {
    id: "yc-w26",
    org: "YC",
    label: "Y Combinator W26",
    cadence: "Winter 2026",
    thesis: "Consumer AI · SMB automation · crypto-adjacent infra",
    color: "var(--avocado)",
    icon: Rocket,
    deals: "~280 startups",
  },
  {
    id: "yc-f25",
    org: "YC",
    label: "Y Combinator F25",
    cadence: "Fall 2025",
    thesis: "Agentic workflows · LLM ops · robotics · climate",
    color: "var(--aqua)",
    icon: Rocket,
    deals: "~260 startups",
  },
  {
    id: "yc-s25",
    org: "YC",
    label: "Y Combinator S25",
    cadence: "Summer 2025",
    thesis: "AI copilots · fintech · biotech · horizontal SaaS",
    color: "var(--tomato)",
    icon: Rocket,
    deals: "~255 startups",
  },
];

export const FundFilter = ({ selected, onChange, onNext, onBack, onExit }) => {
  const toggle = (id) => {
    if (selected.includes(id)) onChange(selected.filter((x) => x !== id));
    else onChange([...selected, id]);
  };

  return (
    <div className="min-h-screen bg-parchment" data-testid="fund-filter-page">
      <StepHeader current="funds" onExit={onExit} />

      <main className="max-w-6xl mx-auto px-5 md:px-8 py-10 md:py-14">
        <div className="grid lg:grid-cols-[1fr_auto] gap-6 items-start mb-10">
          <div className="slide-up">
            <div className="font-mono text-[0.7rem] uppercase tracking-[0.22em] text-tomato mb-3">
              Step 01 / 04 — Shadow funds
            </div>
            <h1 className="font-display text-3xl md:text-5xl text-ink leading-[1.04] max-w-3xl">
              Which funds should Eugene K. tail for thesis signal?
            </h1>
            <p className="mt-4 text-base md:text-lg text-ink/70 max-w-2xl">
              Pick any combination. We'll extract their thesis patterns and hunt the
              second mover in the same category — at a fraction of the valuation.
            </p>
          </div>
          <div className="hidden md:block">
            <KrabsMascot size={140} />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-5 mb-10">
          {FUND_OPTIONS.map((f, i) => {
            const isSel = selected.includes(f.id);
            const Icon = f.icon;
            return (
              <button
                key={f.id}
                onClick={() => toggle(f.id)}
                className={`kk-card selectable p-5 text-left slide-up ${isSel ? "kk-selected" : ""}`}
                style={{ animationDelay: `${i * 60}ms` }}
                data-testid={`fund-card-${f.id}`}
                aria-pressed={isSel}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="grid place-items-center w-11 h-11 rounded-xl border-[2.5px] border-ink flex-shrink-0"
                      style={{ background: f.color, boxShadow: "3px 3px 0 0 var(--ink)" }}
                    >
                      <Icon size={20} strokeWidth={3} className="text-ink" />
                    </div>
                    <div>
                      <div className="font-mono text-[0.68rem] uppercase tracking-[0.22em] text-ink/55">
                        {f.org} · {f.cadence}
                      </div>
                      <div className="font-display text-xl text-ink leading-tight">
                        {f.label}
                      </div>
                    </div>
                  </div>
                  <div
                    className={`w-7 h-7 rounded-md border-[2.5px] border-ink grid place-items-center flex-shrink-0 transition-all ${
                      isSel ? "bg-avocado" : "bg-white"
                    }`}
                    style={{ boxShadow: "2px 2px 0 0 var(--ink)" }}
                  >
                    {isSel && <Check size={18} strokeWidth={4} className="text-white" />}
                  </div>
                </div>
                <p className="mt-4 text-sm text-ink/75 leading-relaxed">
                  <span className="font-mono text-[0.68rem] uppercase tracking-widest text-ink/50">
                    Thesis:{" "}
                  </span>
                  {f.thesis}
                </p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="kk-chip kk-chip-aqua">{f.deals}</span>
                  <span className="font-mono text-[0.68rem] uppercase tracking-widest text-ink/50">
                    {isSel ? "Shadowing ✓" : "Tap to shadow"}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Summary + Nav */}
        <div className="kk-panel p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="font-mono text-[0.7rem] uppercase tracking-[0.22em] text-ink/55">
              Shadowing {selected.length} fund{selected.length === 1 ? "" : "s"}
            </div>
            <div className="font-display text-lg text-ink">
              {selected.length === 0
                ? "Select at least one fund to continue."
                : `Signal coverage: ${Math.min(100, 20 + selected.length * 18)}%`}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="kk-btn kk-btn-ghost"
              data-testid="funds-back-btn"
            >
              <ArrowLeft size={16} strokeWidth={3} />
              Back
            </button>
            <button
              onClick={onNext}
              disabled={selected.length === 0}
              className="kk-btn"
              data-testid="funds-next-btn"
            >
              Configure capital
              <ArrowRight size={18} strokeWidth={3} />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default FundFilter;
