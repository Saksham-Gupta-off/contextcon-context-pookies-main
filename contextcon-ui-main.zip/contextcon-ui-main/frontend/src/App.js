import React, { useState } from "react";
import "@/App.css";
import { Toaster } from "sonner";
import Landing from "./pages/Landing";
import FundFilter from "./pages/FundFilter";
import Capital from "./pages/Capital";
import Blocks from "./pages/Blocks";
import Review from "./pages/Review";

const INITIAL_STATE = {
  step: "landing", // landing | funds | capital | blocks | review
  funds: ["a16z-6mo", "yc-w26"],
  capital: {
    fundSize: 10_000_000,
    numBets: 40,
    chequeSize: 250_000,
    chequeOverridden: false,
  },
  blocks: {
    blockedGeos: ["Russia", "Iran", "China"],
    blockedSectors: ["Gambling", "Crypto", "Defense", "Tobacco"],
    customBlocks: [],
  },
};

function App() {
  const [state, setState] = useState(INITIAL_STATE);

  const go = (step) => setState((s) => ({ ...s, step }));

  return (
    <div className="App" data-testid="app-root">
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "#ffffff",
            border: "2.5px solid #1c2233",
            borderRadius: "14px",
            boxShadow: "5px 5px 0 0 #1c2233",
            fontFamily: "DM Sans, sans-serif",
            fontWeight: 600,
            color: "#1c2233",
          },
        }}
      />

      {state.step === "landing" && <Landing onStart={() => go("funds")} />}

      {state.step === "funds" && (
        <FundFilter
          selected={state.funds}
          onChange={(funds) => setState((s) => ({ ...s, funds }))}
          onNext={() => go("capital")}
          onBack={() => go("landing")}
          onExit={() => go("landing")}
        />
      )}

      {state.step === "capital" && (
        <Capital
          state={state.capital}
          onChange={(capital) => setState((s) => ({ ...s, capital }))}
          onNext={() => go("blocks")}
          onBack={() => go("funds")}
          onExit={() => go("landing")}
        />
      )}

      {state.step === "blocks" && (
        <Blocks
          state={state.blocks}
          onChange={(blocks) => setState((s) => ({ ...s, blocks }))}
          onNext={() => go("review")}
          onBack={() => go("capital")}
          onExit={() => go("landing")}
        />
      )}

      {state.step === "review" && (
        <Review
          state={state}
          onEdit={(step) => go(step)}
          onBack={() => go("blocks")}
          onExit={() => go("landing")}
          onConfirm={() => {
            /* Portfolio construction — built later */
          }}
        />
      )}
    </div>
  );
}

export default App;
