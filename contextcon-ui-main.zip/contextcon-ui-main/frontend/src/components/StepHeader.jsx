import React from "react";
import { CrustyLogo } from "./CrustyLogo";

const STEPS = [
  { key: "funds", label: "Shadow" },
  { key: "capital", label: "Capital" },
  { key: "blocks", label: "Filters" },
  { key: "review", label: "Review" },
];

export const StepHeader = ({ current, onExit }) => {
  const currentIdx = STEPS.findIndex((s) => s.key === current);

  return (
    <header
      className="w-full border-b-[2.5px] border-ink bg-parchment sticky top-0 z-30"
      data-testid="step-header"
    >
      <div className="max-w-6xl mx-auto px-5 md:px-8 py-4 flex items-center justify-between gap-6">
        <button
          onClick={onExit}
          className="flex items-center gap-2"
          data-testid="logo-home-btn"
          aria-label="Back to landing"
        >
          <CrustyLogo />
        </button>

        <div className="hidden md:flex items-center gap-0 flex-1 max-w-xl mx-8">
          {STEPS.map((s, i) => (
            <React.Fragment key={s.key}>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span
                  className={`step-dot ${
                    i < currentIdx ? "done" : i === currentIdx ? "current" : ""
                  }`}
                  data-testid={`step-dot-${s.key}`}
                />
                <span
                  className={`font-mono text-[0.7rem] uppercase tracking-widest ${
                    i === currentIdx ? "text-ink font-bold" : "text-ink/55"
                  }`}
                >
                  {s.label}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div
                  className="flex-1 mx-3 border-t-[2.5px] border-dotted"
                  style={{ borderColor: i < currentIdx ? "var(--avocado)" : "rgba(28,34,51,0.25)" }}
                />
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="kk-chip kk-chip-aqua hidden sm:inline-flex">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          Eugene K. is sourcing
        </div>
      </div>
      <div className="pattern-bar" />
    </header>
  );
};

export default StepHeader;
