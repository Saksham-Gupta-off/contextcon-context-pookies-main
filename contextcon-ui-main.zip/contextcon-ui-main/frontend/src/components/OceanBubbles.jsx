import React, { useMemo } from "react";

/** Animated rising bubbles — for underwater sections. */
export const OceanBubbles = ({ count = 18, className = "" }) => {
  const bubbles = useMemo(() => {
    return Array.from({ length: count }).map((_, i) => {
      const size = 10 + Math.random() * 38;
      return {
        id: i,
        size,
        left: Math.random() * 100,
        delay: Math.random() * 12,
        duration: 10 + Math.random() * 14,
      };
    });
  }, [count]);

  return (
    <div
      className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}
      data-testid="ocean-bubbles"
    >
      {bubbles.map((b) => (
        <span
          key={b.id}
          className="bubble"
          style={{
            width: b.size,
            height: b.size,
            left: `${b.left}%`,
            bottom: `-${b.size + 10}px`,
            animationDelay: `${b.delay}s`,
            animationDuration: `${b.duration}s`,
          }}
        />
      ))}
    </div>
  );
};

export default OceanBubbles;
