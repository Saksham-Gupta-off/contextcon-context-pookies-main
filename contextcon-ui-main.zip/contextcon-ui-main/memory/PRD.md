# Crusty Crab Ventures — PRD

## Problem statement (verbatim)
AI-native VC fund frontend. SpongeBob themed, palette: #258039 (Avocado), #F5BE41 (Yellow Pepper), #31A9B8 (Aqua Blue), #CF3721 (Tomato). Eugene Krabs is the AI GP. Second-mover thesis (shadow a16z / YC, find cheaper mover in same thesis). Onboarding: Landing → Fund filter → Configure capital → Block filters → Review → (Portfolio construction later).

## User choices
- Scope: Frontend-only, no persistence
- Crustdata Company API: subtle hint only
- Eugene Krabs character: stylized SVG mascot inspired by attached palette
- Portfolio construction: deferred

## Architecture
- React 19 + CRA + Tailwind + shadcn primitives available
- State machine in `App.js` (step = landing | funds | capital | blocks | review)
- No backend persistence, no router (single-page step flow)
- Design system: Bungee display + DM Sans body, custom neo-brutalist "kk-*" utility classes, Krusty Krab plank stripes, bubble-rise animations, SVG Eugene K. mascot

## Implemented (Feb 2026)
- Landing: hero, thesis section, how-it-works, marquee signal strip, footer — with Eugene K. mascot, Crustdata hint, fund shadow chips
- Fund filter screen: 5 cards (a16z-6mo, YC P26/W26/F25/S25), multi-select toggles
- Capital screen: fund-size slider ($1M–$100M), bets slider (5–200), auto/override cheque input, deployment forecast bar
- Block filters screen: geo + sector pre-blocked chips, suggestion list, custom blocks (kind + value), chip removal
- Review screen: 4 summary cards with edit shortcuts, confirm CTA, success state with toast

## Components
- `KrabsMascot.jsx` — SVG crab mascot with wobble + claw pinch animations
- `OceanBubbles.jsx` — rising bubble backdrop
- `CrustyLogo.jsx` — logo mark
- `StepHeader.jsx` — progress indicator
- Pages: `Landing.jsx`, `FundFilter.jsx`, `Capital.jsx`, `Blocks.jsx`, `Review.jsx`

## Backlog (P0 / P1 / P2)
- **P0** Portfolio construction screen (deferred at user request)
- **P1** Persistence layer (FastAPI + MongoDB) — save onboarding config
- **P1** Real Crustdata Company API integration + second-mover search
- **P2** AI scoring (thesis-match score per candidate)
- **P2** Auth / user accounts
- **P2** Mobile polish pass (chip overflow, hero stacking)

## Next tasks
1. Portfolio construction screen (ranked second-mover list)
2. Backend persistence for onboarding
3. Crustdata API wiring
